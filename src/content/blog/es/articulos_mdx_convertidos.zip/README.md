# Guía de uso de archivos MDX convertidos

Este documento proporciona información sobre los archivos MDX que han sido convertidos desde el blog WordPress original.

## Estructura de los archivos

Cada archivo MDX sigue la siguiente estructura:

```mdx
---
title: "Título del artículo"
description: "Breve descripción del contenido"
pubDate: YYYY-MM-DD
category: "Categoría principal"
tags: ["etiqueta1", "etiqueta2", ...]
author: "Nombre del autor"
heroImage: "/images/ruta-imagen.png"
---

Contenido del artículo en formato Markdown...
```

## Contenido convertido

Se han convertido un total de 34 artículos desde el archivo WordPress XML original. Todos los artículos mantienen:

- Título original
- Fecha de publicación
- Categorías y etiquetas
- Autor
- Contenido completo en formato Markdown

## Uso de los archivos MDX

Para utilizar estos archivos en tu nueva página:

1. Copia los archivos MDX al directorio de contenido de tu proyecto
2. Asegúrate de que las rutas de las imágenes sean correctas
3. Si es necesario, ajusta las rutas de las imágenes o copia las imágenes a la ubicación correspondiente

## Notas adicionales

- Las imágenes referenciadas en los artículos necesitarán ser transferidas manualmente
- Algunos elementos específicos de WordPress pueden requerir ajustes adicionales
- La estructura del frontmatter (metadatos) sigue el formato del ejemplo proporcionado

## Personalización adicional

Si necesitas realizar ajustes adicionales a los archivos MDX, puedes:

1. Editar manualmente los archivos
2. Modificar el script de conversión para ajustar el formato según tus necesidades
3. Volver a ejecutar el script con parámetros personalizados

El script de conversión se encuentra en: `/home/ubuntu/conversion_wordpress/convertir_wordpress_a_mdx.py`
